create definer = supergiu@`%` trigger answers_update_points
    after insert
    on answers
    for each row
BEGIN
	IF 1=(select is_statistical FROM questions where (idquestionnaire = new.idquestionnaire and question_number = new.question_number)) THEN
		INSERT INTO leaderboard (idquestionnaire, iduser, points)
		VALUES (new.idquestionnaire, new.iduser, 2)
		ON DUPLICATE KEY UPDATE points = points + 2;
	ELSE
		INSERT INTO leaderboard (idquestionnaire, iduser, points)
		VALUES (new.idquestionnaire, new.iduser, 1)
		ON DUPLICATE KEY UPDATE points = points + 1;
	END IF;
END;

