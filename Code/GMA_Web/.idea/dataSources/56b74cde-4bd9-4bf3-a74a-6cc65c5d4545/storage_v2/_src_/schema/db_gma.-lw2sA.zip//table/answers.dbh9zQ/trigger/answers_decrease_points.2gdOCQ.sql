create definer = supergiu@`%` trigger answers_decrease_points
    after delete
    on answers
    for each row
BEGIN
	DECLARE is_statistical_var TINYINT;
    DECLARE question_points INT;
    SELECT is_statistical INTO is_statistical_var FROM questions WHERE (idquestionnaire = old.idquestionnaire and question_number = old.question_number);
    
    IF is_statistical_var = 1 THEN
		SET question_points = 2;
	ELSE
		SET question_points = 1;
	END IF;
        
	IF 0 < (SELECT points-question_points FROM leaderboard WHERE (idquestionnaire = old.idquestionnaire AND iduser = old.iduser)) THEN
		UPDATE leaderboard SET points = points - question_points WHERE (idquestionnaire = old.idquestionnaire AND iduser = old.iduser);
	ELSE
		DELETE FROM leaderboard WHERE (idquestionnaire = old.idquestionnaire AND iduser = old.iduser);
	END IF;
END;

